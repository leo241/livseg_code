import os
import random
import SimpleITK as sitk


def single_domain_dataset(domain='T1', ratio=[3, 1, 1]):
    '''
    单独域的数据集划分
    '''
    paths = os.listdir('D:/study/pga/dataset/mydata2/image')
    random.seed(2023)
    # domain = 'T1'
    # ratio = [8,1,1] # 划分比例
    domain_paths = []
    for path in paths:
        if domain in path:
            domain_paths.append(path)
    random.shuffle(domain_paths)
    train_paths = domain_paths[0:int(len(domain_paths) * ratio[0] / sum(ratio))]
    valid_paths = domain_paths[int(len(domain_paths) * ratio[0] / sum(ratio)):
                               int(len(domain_paths) * ratio[0] / sum(ratio))
                               + int(len(domain_paths) * ratio[1] / sum(ratio))]
    test_paths = domain_paths[int(len(domain_paths) * ratio[0] / sum(ratio))
                              + int(len(domain_paths) * ratio[1] / sum(ratio)):]
    return train_paths, valid_paths, test_paths

def id2name(id,dt = 'train'):
    idstr = str(id)
    l = len(idstr)
    idstr2 = (4-l) * '0' + idstr
    if dt == 'train':
        name = f'Liver_{idstr2}_0000.nii.gz'
    else:
        name = f'Liver_{idstr2}.nii.gz'
    return name

if __name__ == '__main__':
    train_paths, valid_paths, test_paths = single_domain_dataset('T1',ratio=[3,1,1]) # 在这里改变模态
    train_paths = sorted(train_paths) # 排序
    valid_paths = sorted(valid_paths)
    test_paths = sorted(test_paths)
    print('train loading')

    id = 1
    for train in train_paths:
        print(id,train)
        img_dir = os.path.join('D:/study/pga/dataset/mydata2/image',train)
        label_dir = os.path.join('D:/study/pga/dataset/mydata2/label',train)
        name = id2name(id)
        name_label = id2name(id,'label')
        id += 1
        img = sitk.ReadImage(img_dir)
        label = sitk.ReadImage(label_dir)
        sitk.WriteImage(img, os.path.join(r'D:\study\pga\nnUNet-master\DATASET\nnUNet_raw\Dataset001_Liver\imagesTr', name))
        sitk.WriteImage(label,os.path.join(r'D:\study\pga\nnUNet-master\DATASET\nnUNet_raw\Dataset001_Liver\labelsTr', name_label))
    print('\n test loading \n')
    for test in test_paths:
        print(id,test)
        img_dir = os.path.join('D:/study/pga/dataset/mydata2/image',test)
        label_dir = os.path.join('D:/study/pga/dataset/mydata2/label',test)
        name = id2name(id)
        id += 1
        img = sitk.ReadImage(img_dir)
        label = sitk.ReadImage(label_dir)
        sitk.WriteImage(img, os.path.join(r'D:\study\pga\nnUNet-master\DATASET\nnUNet_raw\Dataset001_Liver\imagesTs', name))
        sitk.WriteImage(label,os.path.join(r'D:\study\pga\nnUNet-master\DATASET\nnUNet_raw\Dataset001_Liver\labelsTs', name_label))
