import json
import os

nnUNet_dir = r'D:\study\pga\nnUNet-master\DATASET' #此路径根据自己实际修改

def sts_json():
    info = {
        "channel_names": {
            "0": "CBCT"
        },
        "labels": {
            "background": 0,
            "Liver": 1
        },
        "numTraining": 5,
        "file_ending": ".nii.gz"
    }
    with open(os.path.join(nnUNet_dir,'nnUNet_raw/Dataset001_Liver/dataset.json') ,
              'w') as f:
        json.dump(info, f, indent=4)

sts_json()
